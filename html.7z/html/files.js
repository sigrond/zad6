var files =
[
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "system_plikow_lib.cpp", "system__plikow__lib_8cpp.html", "system__plikow__lib_8cpp" ],
    [ "system_plikow_lib.h", "system__plikow__lib_8h.html", [
      [ "system_plikow", "classsystem__plikow.html", "classsystem__plikow" ],
      [ "best_fit", "structsystem__plikow_1_1best__fit.html", "structsystem__plikow_1_1best__fit" ]
    ] ]
];
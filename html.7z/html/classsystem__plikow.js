var classsystem__plikow =
[
    [ "best_fit", "structsystem__plikow_1_1best__fit.html", "structsystem__plikow_1_1best__fit" ],
    [ "system_plikow", "classsystem__plikow.html#aa524c0d9ccacd0c065c987e33795067f", null ],
    [ "system_plikow", "classsystem__plikow.html#aeeb8dbcabfe77f14ff789c52f20c71bc", null ],
    [ "cp_d_to_v", "classsystem__plikow.html#a2f02775781ed43eb0a07bb7804bb0a72", null ],
    [ "cp_v_to_d", "classsystem__plikow.html#a1f1fc6f593d4b15351b0e66848f13f83", null ],
    [ "create_fs_file", "classsystem__plikow.html#aecf42b5d0c6396820498f906dbc587b3", null ],
    [ "delete_file", "classsystem__plikow.html#a9da490387dd556e111eb715d6f47a002", null ],
    [ "delete_fs_file", "classsystem__plikow.html#a23df79b40e85372447abf8e6b37d77e8", null ],
    [ "powieksz_dziennik", "classsystem__plikow.html#aec4549d6cdf4423bf3cffaff97cba3ff", null ],
    [ "set_fs_size", "classsystem__plikow.html#a7076e65ad0ac25cab1723ba16902a297", null ],
    [ "show_files", "classsystem__plikow.html#acfe2b93c8778fcd60a62d9e4cce1dc60", null ],
    [ "show_fs_map", "classsystem__plikow.html#a39a88c200457a8c70b0ea99e48b19411", null ],
    [ "znajdz_miejsce_na_plik", "classsystem__plikow.html#a81e19d4a6217ebe295bb3a49a0617759", null ],
    [ "znajdz_miejsce_w_dzienniku_wieksze_niz", "classsystem__plikow.html#a40e2a10ecee1c7aeee09837f1007fa61", null ],
    [ "best_fit", "classsystem__plikow.html#a1c25e595c0cf6f6130bcc269b3e0f2d6", null ],
    [ "f", "classsystem__plikow.html#a0cd64bd24d1c8d3e719da6cc55dde273", null ],
    [ "file_exists", "classsystem__plikow.html#ab1b902c53de0e955ebb899a5b61f4502", null ],
    [ "nazwa_systemu", "classsystem__plikow.html#abcb01935a0bf5d8f5b7a42246ef72ca5", null ],
    [ "rozm_fragm_dzien", "classsystem__plikow.html#a2f8ff9592b78bcff00f76f6ad55902ba", null ],
    [ "rozmiar_systemu", "classsystem__plikow.html#a3c7059c7519060bf7ce4d89c9a585c47", null ]
];
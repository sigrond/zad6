var structsystem__plikow_1_1best__fit =
[
    [ "adres", "structsystem__plikow_1_1best__fit.html#a267a7be1b6d41571c02f57d22009da04", null ],
    [ "nadmiar", "structsystem__plikow_1_1best__fit.html#a00293140dac9da95ac7d25ba280eaede", null ],
    [ "rozmiar", "structsystem__plikow_1_1best__fit.html#abc81ee22db410633c538d29b0cd771d7", null ]
];
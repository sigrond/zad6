var searchData=
[
  ['powieksz_5fdziennik',['powieksz_dziennik',['../classsystem__plikow.html#aec4549d6cdf4423bf3cffaff97cba3ff',1,'system_plikow']]]
];

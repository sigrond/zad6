var searchData=
[
  ['delete_5ffile',['delete_file',['../classsystem__plikow.html#a9da490387dd556e111eb715d6f47a002',1,'system_plikow']]],
  ['delete_5ffs_5ffile',['delete_fs_file',['../classsystem__plikow.html#a23df79b40e85372447abf8e6b37d77e8',1,'system_plikow']]]
];

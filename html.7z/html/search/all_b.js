var searchData=
[
  ['znajdz_5fmiejsce_5fna_5fplik',['znajdz_miejsce_na_plik',['../classsystem__plikow.html#a81e19d4a6217ebe295bb3a49a0617759',1,'system_plikow']]],
  ['znajdz_5fmiejsce_5fw_5fdzienniku_5fwieksze_5fniz',['znajdz_miejsce_w_dzienniku_wieksze_niz',['../classsystem__plikow.html#a40e2a10ecee1c7aeee09837f1007fa61',1,'system_plikow']]]
];

var searchData=
[
  ['rozm_5ffragm_5fdzien',['rozm_fragm_dzien',['../classsystem__plikow.html#a2f8ff9592b78bcff00f76f6ad55902ba',1,'system_plikow']]],
  ['rozmiar',['rozmiar',['../structsystem__plikow_1_1best__fit.html#abc81ee22db410633c538d29b0cd771d7',1,'system_plikow::best_fit']]],
  ['rozmiar_5fsystemu',['rozmiar_systemu',['../classsystem__plikow.html#a3c7059c7519060bf7ce4d89c9a585c47',1,'system_plikow']]]
];

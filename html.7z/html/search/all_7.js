var searchData=
[
  ['nadmiar',['nadmiar',['../structsystem__plikow_1_1best__fit.html#a00293140dac9da95ac7d25ba280eaede',1,'system_plikow::best_fit']]],
  ['nazwa_5fsystemu',['nazwa_systemu',['../classsystem__plikow.html#abcb01935a0bf5d8f5b7a42246ef72ca5',1,'system_plikow']]]
];

var searchData=
[
  ['set_5ffs_5fsize',['set_fs_size',['../classsystem__plikow.html#a7076e65ad0ac25cab1723ba16902a297',1,'system_plikow']]],
  ['show_5ffiles',['show_files',['../classsystem__plikow.html#acfe2b93c8778fcd60a62d9e4cce1dc60',1,'system_plikow']]],
  ['show_5ffs_5fmap',['show_fs_map',['../classsystem__plikow.html#a39a88c200457a8c70b0ea99e48b19411',1,'system_plikow']]],
  ['system_5fplikow',['system_plikow',['../classsystem__plikow.html#aa524c0d9ccacd0c065c987e33795067f',1,'system_plikow::system_plikow(std::string nazwa)'],['../classsystem__plikow.html#aeeb8dbcabfe77f14ff789c52f20c71bc',1,'system_plikow::system_plikow(std::string nazwa, unsigned long int rozmiar)']]]
];

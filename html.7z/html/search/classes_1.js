var searchData=
[
  ['system_5fplikow',['system_plikow',['../classsystem__plikow.html',1,'']]]
];

var searchData=
[
  ['best_5ffit',['best_fit',['../structsystem__plikow_1_1best__fit.html',1,'system_plikow']]]
];

var searchData=
[
  ['adres',['adres',['../structsystem__plikow_1_1best__fit.html#a267a7be1b6d41571c02f57d22009da04',1,'system_plikow::best_fit']]]
];

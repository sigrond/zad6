var searchData=
[
  ['lista_20rzeczy_20do_20zrobienia',['Lista rzeczy do zrobienia',['../todo.html',1,'']]]
];

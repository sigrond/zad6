var searchData=
[
  ['cp_5fd_5fto_5fv',['cp_d_to_v',['../classsystem__plikow.html#a2f02775781ed43eb0a07bb7804bb0a72',1,'system_plikow']]],
  ['cp_5fv_5fto_5fd',['cp_v_to_d',['../classsystem__plikow.html#a1f1fc6f593d4b15351b0e66848f13f83',1,'system_plikow']]],
  ['create_5ffs_5ffile',['create_fs_file',['../classsystem__plikow.html#aecf42b5d0c6396820498f906dbc587b3',1,'system_plikow']]]
];

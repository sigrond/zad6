var searchData=
[
  ['system_5fplikow_5flib_2ecpp',['system_plikow_lib.cpp',['../system__plikow__lib_8cpp.html',1,'']]],
  ['system_5fplikow_5flib_2eh',['system_plikow_lib.h',['../system__plikow__lib_8h.html',1,'']]]
];

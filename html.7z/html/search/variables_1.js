var searchData=
[
  ['best_5ffit',['best_fit',['../classsystem__plikow.html#a1c25e595c0cf6f6130bcc269b3e0f2d6',1,'system_plikow']]]
];

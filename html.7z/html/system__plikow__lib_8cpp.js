var system__plikow__lib_8cpp =
[
    [ "my_cmp", "system__plikow__lib_8cpp.html#a7069a256c495b5df8d7e904741b2d44f", null ],
    [ "my_cmp2", "system__plikow__lib_8cpp.html#aed1b9df4f24daf38a1a1b0313e5a2a25", null ]
];
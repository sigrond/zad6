var annotated =
[
    [ "system_plikow", "classsystem__plikow.html", "classsystem__plikow" ]
];